import {
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Permiso } from '../entities/permiso.entity';
import { CrearPermisoDto, ResolverPermisoDto } from '../dto/permiso.dto';
import { Usuario } from '../../usuario/entities/usuario.entity';

@Injectable()
export class PermisoService {
  constructor(
    @InjectRepository(Permiso)
    private permisoRepo: Repository<Permiso>,

    @InjectRepository(Usuario)
    private usuarioRepo: Repository<Usuario>,
  ) {}

  async crear(dto: CrearPermisoDto) {
    const usuario = await this.usuarioRepo.findOne({
      where: { id_usuario: dto.id_solicitante },
    });

    if (!usuario) throw new BadRequestException('Solicitante no existe');

    // Validación de fechas
    if (new Date(dto.fecha_fin) < new Date(dto.fecha_inicio)) {
      throw new BadRequestException(
        'La fecha final no puede ser anterior a la inicial.',
      );
    }

    const permiso = this.permisoRepo.create({
      ...dto,
      estado: 'PENDIENTE',
    });

    return this.permisoRepo.save(permiso);
  }

  async listarPendientes() {
    return this.permisoRepo.find({
      where: { estado: 'PENDIENTE' },
      relations: ['solicitante'],
    });
  }

  async resolver(id: string, dto: ResolverPermisoDto) {
    const permiso = await this.permisoRepo.findOne({
      where: { id_permiso: id },
      relations: ['solicitante'],
    });

    if (!permiso) throw new NotFoundException('Permiso no encontrado');

    // Un usuario no puede resolver su propio permiso
    if (permiso.id_solicitante === dto.id_resolvedor) {
      throw new BadRequestException(
        'Un usuario no puede resolver su propio permiso.',
      );
    }

    permiso.estado = dto.estado;
    permiso.id_resolvedor = dto.id_resolvedor;
    permiso.resuelto_en = new Date();

    return this.permisoRepo.save(permiso);
  }
}
