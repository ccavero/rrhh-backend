import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Usuario } from '../../usuario/entities/usuario.entity';

@Entity('permiso')
export class Permiso {
  @PrimaryGeneratedColumn('uuid')
  id_permiso: string;

  @Column({ length: 30 })
  tipo: string;

  @Column({ type: 'text' })
  motivo: string;

  @Column({ type: 'date' })
  fecha_inicio: Date;

  @Column({ type: 'date' })
  fecha_fin: Date;

  @Column({ length: 20 })
  estado: string; // PENDIENTE / APROBADO / RECHAZADO

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  creado_en: Date;

  @Column({ type: 'timestamp', nullable: true })
  resuelto_en: Date;

  // --------------------------
  // Relaciones
  // --------------------------

  @ManyToOne(() => Usuario, (u) => u.permisos_solicitados)
  @JoinColumn({ name: 'id_solicitante' })
  solicitante: Usuario;

  @Column({ type: 'uuid' })
  id_solicitante: string;

  @ManyToOne(() => Usuario, (u) => u.permisos_resueltos, { nullable: true })
  @JoinColumn({ name: 'id_resolvedor' })
  resolvedor?: Usuario;

  @Column({ type: 'uuid', nullable: true })
  id_resolvedor: string | null;
}
