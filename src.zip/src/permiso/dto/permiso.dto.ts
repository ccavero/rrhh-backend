import {
  IsUUID,
  IsString,
  IsNotEmpty,
  IsDateString,
  IsIn,
} from 'class-validator';

export class CrearPermisoDto {
  @IsUUID()
  id_solicitante: string;

  @IsString()
  @IsNotEmpty()
  tipo: string;

  @IsString()
  @IsNotEmpty()
  motivo: string;

  @IsDateString()
  fecha_inicio: string;

  @IsDateString()
  fecha_fin: string;
}

export class ResolverPermisoDto {
  @IsUUID()
  id_resolvedor: string;

  @IsIn(['APROBADO', 'RECHAZADO'])
  estado: string;
}
