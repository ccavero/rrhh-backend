import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(
      ROLES_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (!requiredRoles) {
      return true; // endpoint sin roles → cualquiera autenticado puede entrar
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user || !user.id_rol) {
      throw new ForbiddenException('Usuario sin rol asignado.');
    }

    // user.id_rol viene del JWT → comparamos
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    if (!requiredRoles.includes(user.id_rol)) {
      throw new ForbiddenException('No tiene permisos para acceder.');
    }

    return true;
  }
}
