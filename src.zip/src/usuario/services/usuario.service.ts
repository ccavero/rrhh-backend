import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { Usuario } from '../entities/usuario.entity';
import { CrearUsuarioDto, ActualizarUsuarioDto } from '../dto/usuario.dto';

@Injectable()
export class UsuarioService {
  constructor(
    @InjectRepository(Usuario)
    private usuarioRepo: Repository<Usuario>,
  ) {}

  async crear(dto: CrearUsuarioDto) {
    const existe = await this.usuarioRepo.findOne({
      where: { email: dto.email },
    });

    if (existe) {
      throw new BadRequestException('El email ya está registrado');
    }

    const hash = await bcrypt.hash(dto.password, 10);

    const nuevo = this.usuarioRepo.create({
      nombre: dto.nombre,
      apellido: dto.apellido,
      email: dto.email,
      password_hash: hash,
      id_rol: dto.id_rol,
      estado: 'ACTIVO',
    });

    return this.usuarioRepo.save(nuevo);
  }

  async listar() {
    return this.usuarioRepo.find();
  }

  async buscar(id: string) {
    const usuario = await this.usuarioRepo.findOne({
      where: { id_usuario: id },
    });

    if (!usuario) throw new NotFoundException('Usuario no encontrado');

    return usuario;
  }

  async actualizar(id: string, dto: ActualizarUsuarioDto) {
    const usuario = await this.buscar(id);

    // Si llega password, generar el hash
    if (dto.password) {
      usuario.password_hash = await bcrypt.hash(dto.password, 10);
      delete dto.password; // limpiamos el campo para evitar sobrescribir
    }

    // Mezclar el resto de campos del DTO con el usuario
    Object.assign(usuario, dto);

    return this.usuarioRepo.save(usuario);
  }

  async eliminar(id: string) {
    const usuario = await this.buscar(id);
    await this.usuarioRepo.remove(usuario);
    return { mensaje: 'Usuario eliminado' };
  }
}
