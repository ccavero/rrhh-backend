import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Asistencia } from '../../asistencia/entities/asistencia.entity';
import { Permiso } from '../../permiso/entities/permiso.entity';

@Entity('usuario')
export class Usuario {
  @PrimaryGeneratedColumn('uuid')
  id_usuario: string;

  @Column({ length: 100 })
  nombre: string;

  @Column({ length: 100 })
  apellido: string;

  @Column({ length: 120, unique: true })
  email: string;

  @Column({ length: 255 })
  password_hash: string;

  @Column({ length: 20 })
  estado: string; // ACTIVO / INACTIVO

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  creado_en: Date;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  actualizado_en: Date;

  @Column({ type: 'varchar', length: 20 })
  id_rol: string; // ADMIN, FUNCIONARIO, RRHH

  // --------------------------
  // Relaciones
  // --------------------------

  // Un usuario puede registrar muchas asistencias
  @OneToMany(() => Asistencia, (a) => a.usuario)
  asistencias: Asistencia[];

  // Un usuario puede validar asistencias
  @OneToMany(() => Asistencia, (a) => a.validador)
  asistencias_validadas: Asistencia[];

  // Un usuario puede solicitar permisos
  @OneToMany(() => Permiso, (p) => p.solicitante)
  permisos_solicitados: Permiso[];

  // Un usuario puede resolver permisos
  @OneToMany(() => Permiso, (p) => p.resolvedor)
  permisos_resueltos: Permiso[];
}
