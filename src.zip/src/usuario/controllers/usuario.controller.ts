import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
} from '@nestjs/common';
import { UsuarioService } from '../services/usuario.service';
import { CrearUsuarioDto, ActualizarUsuarioDto } from '../dto/usuario.dto';
import { Roles } from '../../common/decorators/roles.decorator';

@Controller('usuarios')
export class UsuarioController {
  constructor(private readonly usuarioService: UsuarioService) {}

  @Post()
  crear(@Body() dto: CrearUsuarioDto) {
    return this.usuarioService.crear(dto);
  }

  @Roles('RRHH')
  @Get()
  listar() {
    return this.usuarioService.listar();
  }

  @Get(':id')
  buscar(@Param('id') id: string) {
    return this.usuarioService.buscar(id);
  }

  @Patch(':id')
  actualizar(@Param('id') id: string, @Body() dto: ActualizarUsuarioDto) {
    return this.usuarioService.actualizar(id, dto);
  }

  @Delete(':id')
  eliminar(@Param('id') id: string) {
    return this.usuarioService.eliminar(id);
  }
}
