import { NestFactory } from '@nestjs/core';
import { AppModule } from '../app.module';
import { UserSeeder } from './seeders/user.seeder';
import { AsistenciaSeeder } from './seeders/asistencia.seeder';
import { PermisoSeeder } from './seeders/permiso.seeder';

async function bootstrap() {
  const app = await NestFactory.createApplicationContext(AppModule);

  console.log('🌱 Iniciando generación de datos de prueba...');

  await new UserSeeder(app).run();
  await new AsistenciaSeeder(app).run();
  await new PermisoSeeder(app).run();

  console.log('🌱 Seed completado exitosamente.');

  await app.close();
}

bootstrap();
