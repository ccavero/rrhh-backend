import { INestApplicationContext } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Permiso } from '../../permiso/entities/permiso.entity';
import { Usuario } from '../../usuario/entities/usuario.entity';

export class PermisoSeeder {
  private permisoRepo: Repository<Permiso>;
  private usuarioRepo: Repository<Usuario>;

  constructor(app: INestApplicationContext) {
    this.permisoRepo = app.get('PermisoRepository');
    this.usuarioRepo = app.get('UsuarioRepository');
  }

  async run() {
    console.log('→ Insertando permisos...');

    // Obtener solicitante (FUNCIONARIO)
    const funcionario = await this.usuarioRepo.findOne({
      where: { id_rol: 'FUNCIONARIO' },
    });

    // Obtener resolvedor (RRHH)
    const rrhh = await this.usuarioRepo.findOne({
      where: { id_rol: 'RRHH' },
    });

    if (!funcionario) {
      console.log('⚠ No se encontró FUNCIONARIO. Saltando permisos.');
      return;
    }

    const permiso1 = this.permisoRepo.create({
      id_solicitante: funcionario.id_usuario,
      tipo: 'PERSONAL',
      motivo: 'Cita médica',
      fecha_inicio: new Date(),
      fecha_fin: new Date(),
      estado: 'PENDIENTE',
    });

    const permiso2 = this.permisoRepo.create({
      id_solicitante: funcionario.id_usuario,
      tipo: 'PERSONAL',
      motivo: 'Trámite personal',
      fecha_inicio: new Date(),
      fecha_fin: new Date(),
      estado: 'APROBADO',
      id_resolvedor: rrhh?.id_usuario ?? null,
      resuelto_en: new Date(),
    });

    await this.permisoRepo.save([permiso1, permiso2]);

    console.log('✓ Permisos insertados');
  }
}
