import { INestApplicationContext } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Asistencia } from '../../asistencia/entities/asistencia.entity';
import { Usuario } from '../../usuario/entities/usuario.entity';

export class AsistenciaSeeder {
  private asistenciaRepo: Repository<Asistencia>;
  private usuarioRepo: Repository<Usuario>;

  constructor(app: INestApplicationContext) {
    this.asistenciaRepo = app.get('AsistenciaRepository');
    this.usuarioRepo = app.get('UsuarioRepository');
  }

  async run() {
    console.log('→ Insertando asistencias...');

    const funcionario = await this.usuarioRepo.findOne({
      where: { id_rol: 'FUNCIONARIO' },
    });

    if (!funcionario) {
      console.log('⚠ No se encontró funcionario. Saltando asistencias.');
      return;
    }

    const entrada = this.asistenciaRepo.create({
      id_usuario: funcionario.id_usuario,
      tipo: 'entrada',
      fecha_hora: new Date(),
      estado: 'VALIDA',
      origen: 'web',
      ip_registro: '127.0.0.1',
    });

    const salida = this.asistenciaRepo.create({
      id_usuario: funcionario.id_usuario,
      tipo: 'salida',
      fecha_hora: new Date(),
      estado: 'VALIDA',
      origen: 'web',
      ip_registro: '127.0.0.1',
    });

    await this.asistenciaRepo.save([entrada, salida]);

    console.log('✓ Asistencias insertadas');
  }
}
