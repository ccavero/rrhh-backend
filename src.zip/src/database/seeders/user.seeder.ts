import { INestApplicationContext } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Usuario } from '../../usuario/entities/usuario.entity';
import * as bcrypt from 'bcrypt';

export class UserSeeder {
  private repo: Repository<Usuario>;

  constructor(app: INestApplicationContext) {
    this.repo = app.get('UsuarioRepository');
  }

  async run() {
    console.log('→ Insertando usuarios...');

    const password = await bcrypt.hash('123456', 10);

    const users = [
      {
        nombre: 'Admin',
        apellido: 'Principal',
        email: 'admin@rrhh.com',
        password_hash: password,
        estado: 'ACTIVO',
        id_rol: 'ADMIN',
      },
      {
        nombre: 'Carlos',
        apellido: 'Funcionario',
        email: 'funcionario@rrhh.com',
        password_hash: password,
        estado: 'ACTIVO',
        id_rol: 'FUNCIONARIO',
      },
      {
        nombre: 'Laura',
        apellido: 'Validadora',
        email: 'rrhh@rrhh.com',
        password_hash: password,
        estado: 'ACTIVO',
        id_rol: 'RRHH',
      },
    ];

    await this.repo.save(users);

    console.log('✓ Usuarios insertados');
  }
}
