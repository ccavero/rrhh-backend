import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThan } from 'typeorm';
import { Asistencia } from '../entities/asistencia.entity';
import { CrearAsistenciaDto } from '../dto/asistencia.dto';
import { Usuario } from '../../usuario/entities/usuario.entity';

@Injectable()
export class AsistenciaService {
  constructor(
    @InjectRepository(Asistencia)
    private asistenciaRepo: Repository<Asistencia>,

    @InjectRepository(Usuario)
    private usuarioRepo: Repository<Usuario>,
  ) {}

  async crear(dto: CrearAsistenciaDto) {
    const usuario = await this.usuarioRepo.findOne({
      where: { id_usuario: dto.id_usuario },
    });

    if (!usuario) {
      throw new BadRequestException('El usuario no existe.');
    }

    // Buscar últimas asistencias válidas del usuario hoy
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    const ultima = await this.asistenciaRepo.findOne({
      where: {
        id_usuario: dto.id_usuario,
        estado: 'VALIDA',
        fecha_hora: MoreThan(hoy),
      },
      order: { fecha_hora: 'DESC' },
    });

    // Regla: no duplicar entrada → entrada
    if (ultima && ultima.tipo === dto.tipo) {
      throw new BadRequestException(
        `No puede registrar dos asistencias consecutivas de tipo "${dto.tipo}".`,
      );
    }

    // Regla: no permitir salida sin entrada previa
    if (dto.tipo === 'salida' && !ultima) {
      throw new BadRequestException(
        'Debe registrar una entrada antes de registrar salida.',
      );
    }

    const registro = this.asistenciaRepo.create({
      ...dto,
      fecha_hora: new Date(),
      estado: 'VALIDA',
    });

    return this.asistenciaRepo.save(registro);
  }

  async listar() {
    return this.asistenciaRepo.find({
      relations: ['usuario', 'validador'],
      order: { fecha_hora: 'DESC' },
    });
  }
}
