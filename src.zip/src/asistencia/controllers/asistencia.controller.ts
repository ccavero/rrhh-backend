import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { AsistenciaService } from '../services/asistencia.service';
import { CrearAsistenciaDto } from '../dto/asistencia.dto';
import { User } from '../../common/decorators/user.decorator';
import { AuthGuard } from '@nestjs/passport';
import { Roles } from '../../common/decorators/roles.decorator';

@Controller('asistencia')
export class AsistenciaController {
  constructor(private asistenciaService: AsistenciaService) {}

  @Post()
  @UseGuards(AuthGuard('jwt'))
  crear(@Body() dto: CrearAsistenciaDto, @User() usuario) {
    // Forzamos id del usuario desde el token
    const data = {
      ...dto,
      id_usuario: usuario.id_usuario,
    };

    return this.asistenciaService.crear(data);
  }

  @Roles('ADMIN')
  @Get()
  listar() {
    return this.asistenciaService.listar();
  }
}
