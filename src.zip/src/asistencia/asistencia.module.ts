import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Asistencia } from './entities/asistencia.entity';
import { AsistenciaService } from './services/asistencia.service';
import { AsistenciaController } from './controllers/asistencia.controller';
import { Usuario } from '../usuario/entities/usuario.entity';
import { DataSource } from 'typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Asistencia, Usuario])],
  providers: [
    AsistenciaService,
    {
      provide: 'AsistenciaRepository',
      useFactory: (dataSource: DataSource) =>
        dataSource.getRepository(Asistencia),
      inject: [DataSource],
    },
  ],
  exports: ['AsistenciaRepository'],
  controllers: [AsistenciaController],
})
export class AsistenciaModule {}
