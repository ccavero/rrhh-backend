import { IsNotEmpty, IsString, IsUUID, IsIn, IsIP } from 'class-validator';

export class CrearAsistenciaDto {
  @IsUUID()
  @IsNotEmpty()
  id_usuario: string;

  @IsString()
  @IsIn(['entrada', 'salida'])
  tipo: string;

  @IsString()
  @IsNotEmpty()
  origen: string;

  @IsIP()
  ip_registro: string;
}
